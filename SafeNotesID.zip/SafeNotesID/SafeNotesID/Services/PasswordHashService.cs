﻿using System.Security.Cryptography;
using System.Text;

namespace SafeNotesID.Services
{
	public static class PasswordHashService
	{
		public static string HashPassword(string password, string salt)
		{
			using var sha256 = SHA256.Create();
			var bytes = Encoding.UTF8.GetBytes(password + salt);
			var hash = sha256.ComputeHash(bytes);
			return Convert.ToBase64String(hash);
		}

		public static string GenerateSalt()
		{
			var buffer = new byte[16];
			RandomNumberGenerator.Fill(buffer);
			return Convert.ToBase64String(buffer);
		}
	}
}
