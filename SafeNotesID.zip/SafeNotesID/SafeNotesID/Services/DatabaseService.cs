﻿using System.Data;
using MySql.Data.MySqlClient;
using SafeNotesID.Models;

namespace SafeNotesID.Services
{
	public static class DatabaseService
	{
		private static string connString = "server=127.0.0.1;user=root;password=;database=safenotes;";

		public static User? GetUser(string username)
		{
			using var conn = new MySqlConnection(connString);
			conn.Open();
			using var cmd = conn.CreateCommand();
			cmd.CommandText = "SELECT id, username, password_hash, salt FROM users WHERE username=@u LIMIT 1";
			cmd.Parameters.AddWithValue("@u", username);
			using var rdr = cmd.ExecuteReader();
			if (rdr.Read())
			{
				return new User
				{
					Id = rdr.GetInt32("id"),
					Username = rdr.GetString("username"),
					PasswordHash = rdr.GetString("password_hash"),
					Salt = rdr.GetString("salt")
				};
			}
			return null;
		}

		// 👇 Tambahkan method ini
		public static void SaveUser(string username, string passwordHash, string salt)
		{
			using var conn = new MySqlConnection(connString);
			conn.Open();
			using var cmd = conn.CreateCommand();
			cmd.CommandText = "INSERT INTO users (username, password_hash, salt) VALUES (@u,@h,@s)";
			cmd.Parameters.AddWithValue("@u", username);
			cmd.Parameters.AddWithValue("@h", passwordHash);
			cmd.Parameters.AddWithValue("@s", salt);
			cmd.ExecuteNonQuery();
		}

		public static DataTable GetNotesByUser(int userId)
		{
			using var conn = new MySqlConnection(connString);
			conn.Open();
			using var cmd = conn.CreateCommand();
			cmd.CommandText = "SELECT id, title, updated_at FROM notes WHERE user_id=@uid ORDER BY updated_at DESC";
			cmd.Parameters.AddWithValue("@uid", userId);

			using var da = new MySqlDataAdapter(cmd);
			DataTable dt = new DataTable();
			da.Fill(dt);
			return dt;
		}

	}
}
