﻿using System;
using System.Data;
using System.Windows.Forms;
using SafeNotesID.Services;

namespace SafeNotesID.Forms
{
	public partial class NotesForm : Form
	{
		[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
		[System.ComponentModel.Browsable(false)]
		public int CurrentUserId { get; set; }

		[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
		[System.ComponentModel.Browsable(false)]
		public string? CurrentUsername { get; set; }  // nullable untuk hilangkan warning

		public NotesForm()
		{
			InitializeComponent();
			this.Load += NotesForm_Load;   // pastikan event load selalu terhubung
		}

		private void LoadNotes()
		{
			dgvNotes.DataSource = DatabaseService.GetNotesByUser(CurrentUserId);
			dgvNotes.ClearSelection();
		}

		private void NotesForm_Load(object? sender, EventArgs e)
		{
			lblWelcome.Text = $"Welcome, {CurrentUsername}";
			LoadNotes();  // pindahkan ke sini agar data muncul setelah `CurrentUserId` diterima dari LoginForm
		}

		private void dgvNotes_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}
	}
}
