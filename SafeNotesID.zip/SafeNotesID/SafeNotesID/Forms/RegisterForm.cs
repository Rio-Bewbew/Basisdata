﻿using System;
using System.Windows.Forms;
using SafeNotesID.Services;

namespace SafeNotesID.Forms
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirm.Text))
            {
                MessageBox.Show("Semua field wajib diisi.");
                return;
            }

            if (txtPassword.Text != txtConfirm.Text)
            {
                MessageBox.Show("Password dan konfirmasi tidak cocok.");
                return;
            }

            string salt = PasswordHashService.GenerateSalt();
            string hash = PasswordHashService.HashPassword(txtPassword.Text, salt);

            try
            {
                DatabaseService.SaveUser(txtUsername.Text, hash, salt);
                MessageBox.Show("Registrasi berhasil! Silakan login.");

                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal registrasi: " + ex.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
