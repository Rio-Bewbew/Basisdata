﻿namespace SafeNotesID.Forms
{
    partial class NotesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            dgvNotes = new DataGridView();
            btnAddNote = new Button();
            btnDeleteNote = new Button();
            btnEditNote = new Button();
            btnLogout = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvNotes).BeginInit();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcome.Location = new Point(52, 36);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(209, 38);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome, user";
            // 
            // dgvNotes
            // 
            dgvNotes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvNotes.Dock = DockStyle.Bottom;
            dgvNotes.Location = new Point(0, 225);
            dgvNotes.Name = "dgvNotes";
            dgvNotes.RowHeadersWidth = 62;
            dgvNotes.Size = new Size(800, 225);
            dgvNotes.TabIndex = 1;
            // 
            // btnAddNote
            // 
            btnAddNote.Location = new Point(34, 173);
            btnAddNote.Name = "btnAddNote";
            btnAddNote.Size = new Size(112, 34);
            btnAddNote.TabIndex = 2;
            btnAddNote.Text = "Add";
            btnAddNote.UseVisualStyleBackColor = true;
            // 
            // btnDeleteNote
            // 
            btnDeleteNote.Location = new Point(270, 173);
            btnDeleteNote.Name = "btnDeleteNote";
            btnDeleteNote.Size = new Size(112, 34);
            btnDeleteNote.TabIndex = 3;
            btnDeleteNote.Text = "Delete";
            btnDeleteNote.UseVisualStyleBackColor = true;
            // 
            // btnEditNote
            // 
            btnEditNote.Location = new Point(152, 173);
            btnEditNote.Name = "btnEditNote";
            btnEditNote.Size = new Size(112, 34);
            btnEditNote.TabIndex = 4;
            btnEditNote.Text = "Edit";
            btnEditNote.UseVisualStyleBackColor = true;
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(388, 173);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(112, 34);
            btnLogout.TabIndex = 5;
            btnLogout.Text = "Delete";
            btnLogout.UseVisualStyleBackColor = true;
            // 
            // NotesForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLogout);
            Controls.Add(btnEditNote);
            Controls.Add(btnDeleteNote);
            Controls.Add(btnAddNote);
            Controls.Add(dgvNotes);
            Controls.Add(lblWelcome);
            Name = "NotesForm";
            Text = "NotesForm";
            ((System.ComponentModel.ISupportInitialize)dgvNotes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private DataGridView dgvNotes;
        private Button btnAddNote;
        private Button btnDeleteNote;
        private Button btnEditNote;
        private Button btnLogout;
    }
}