﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SafeNotesID.Services;

namespace SafeNotesID.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Username dan Password wajib diisi.");
                return;
            }

            var user = DatabaseService.GetUser(txtUsername.Text);
            if (user == null)
            {
                MessageBox.Show("User tidak ditemukan.");
                return;
            }

            string hash = PasswordHashService.HashPassword(txtPassword.Text, user.Salt);
            if (hash == user.PasswordHash)
            {
                NotesForm nf = new NotesForm();
                nf.CurrentUserId = user.Id;
                nf.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Password salah.");
            }
        }

		private void btnRegister_Click(object sender, EventArgs e)
		{
			RegisterForm rf = new RegisterForm();
			rf.Show();
			this.Hide();
		}

	}
}
